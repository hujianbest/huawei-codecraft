package com.elasticcloudservice.predict;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.elasticcloudservice.predict.funs.*;;
import com.elasticcloudservice.predict.base.*;
import com.elasticcloudservice.predict.gga.*;


public class Predict {

	public static String[] predictVm(String[] ecsContent, String[] inputContent) {

	List<String> history = new ArrayList<String>();

		for (int i = 1; i < ecsContent.length; i++) {

			if (ecsContent[i].contains("\t")
					&& ecsContent[i].split("\t").length == 3) {

				String[] array = ecsContent[i].split("\t");
				String uuid = array[0];
				String flavorName = array[1];
				String createTime = array[2];

				history.add(uuid + " " + flavorName + " " + createTime);
			}
		}

        InputMsg input = new InputMsg(inputContent);
        Map<Flavor,Map<String,Integer>> orgDataWithZeros = Pretreatment.timesInOneDayWithZeros(history, input);
        Filter.filte(orgDataWithZeros);        
        Map<Flavor,Double> average = Average.getSimpleAverage(orgDataWithZeros);
        Map<Flavor,Integer> predictResult = Average.avgAdjust(average, input.getDays(), 6.5);//
        DNA assignresult = Solution.solution(predictResult,input);
        String[] result = OutputFormat.getResultv3(predictResult, assignresult.getServerList(),input);
        return result;
	}

}
