package com.elasticcloudservice.predict.gga;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.elasticcloudservice.predict.base.*;


public class Evolution{

    List<DNA> group;
    private final int groupsize;
    private final double ratec;
    private final double ratem;
    private final int generation;

    private List<Flavor> VMdata;
    private final List<ServerStd> serverstds;
    private final int vmamount;
    private final int cpuneed;
    private final int ramneed;
    private final int serveramonut;
    private final int numOfServerstd;


    public Evolution(List<Flavor> VMdata,int numOfServerstd, List<ServerStd> serverstds,int serveramonut,int groupsize, double ratec,double ratem,int generation){
        this.group = new LinkedList<>();
        this.VMdata=VMdata;
        this.serverstds=serverstds;
        this.serveramonut = serveramonut;
        this.groupsize = groupsize;
        this.ratec=ratec;
        this.ratem=ratem;
        this.generation=generation;
        this.vmamount =VMdata.size();
        this.numOfServerstd=numOfServerstd;
        int a=0;
        int b=0;
        for(Flavor f:VMdata){
            a+=f.getCpu();
            b+=f.getRamMB();
        }
        cpuneed=a;
        ramneed=b;
        
    }

    public void start(){
        this.init();
        for(int i =0;i<generation;i++){
            this.copulate();
            this.naturalSelection();
            //System.out.println("GroupSize = "+this.group.size());
            //System.out.println("MAX_CPUfiness = "+this.getMaxFitness());
            //System.out.println("MIN_CPUfiness = "+this.getMinFitness());
            //System.out.println();
        }
    }


    /**
     * 初试化族群
     * @param groupsize 族群大小
     * @param ratec 交配比率
     * @param ratem 突变几率
     * @param generation 代数
     */
    private void init(){
        for(int i=0;i<groupsize;i++){
            this.group.add(new DNA(VMdata, numOfServerstd, serverstds, vmamount, cpuneed, ramneed, serveramonut));
        }
    }

    /**
     * 交配一次，返回孩子
     * 要去除重复分配的部分
     * 以dad的优秀基因为参照，删除其他所有与dad基因有重复的地方，未分配的重新分配到当前fi最小的server上，放不下就往fi次小的server上放，以此类推
     * 需要单独写个分配未分配flavor的函数，后面基因突变会再次用到
     */
    private DNA childoOf(DNA dad,DNA mom){
        Server bestgene = dad.getBest();
        DNA child = (DNA)mom.clone();//有可能失败，加判断，失败就不要这个孩子？要mom
        if(child.add(bestgene)){
            return child;
        }else{
            return (DNA)mom.clone();
        }
            
    }




    /**一代交配 */
    private void copulate(){
        int pickc = (int)(groupsize*ratec);
        Collections.shuffle(group);
        List<DNA> childgroup = new LinkedList<>();
        for(int i=0;i<pickc;i++){//随机选择
            childgroup.add(this.childoOf(group.get(i), group.get(i+1)));
        }
        //基因突变
         int pickm = (int)(childgroup.size()*ratem);
         Collections.shuffle(childgroup);
         for(int i=0;i<pickm;i++){
             DNA mutation = (DNA)childgroup.get(i).clone();
             if(mutation.mute()){
                 childgroup.remove(i);
                 childgroup.add(mutation);
             }
         }
        group.addAll(childgroup);//将孩子们加入到族群中
    }


    /**
     * 一代筛选，删掉多少？保持数量稳定，删掉groupsize*ratec 
     * 对DNA进行排序，按CPUfitness，DNA需要实现compareTo
     */
    private void naturalSelection(){
        Collections.sort(group);//默认从小达到排序
        for(int i=0;i<groupsize*ratec;i++){
            group.remove(0);
        }
    }

    //返回当前的最大CPUfitness
    public double getMaxFitness(){
        double Max = 0;
        for(DNA dna : group){
            Max = Math.max(Max, dna.getFitness());
        }
        return Max;
    }

    //返回当前的最小CPUfitness
    public double getMinFitness(){
        double Min = 1;
        for(DNA dna : group){
            Min = Math.min(Min, dna.getFitness());
        }
        return Min;
    }


    public DNA end(){
        Collections.sort(group);//默认从小达到排序
        for(int i=1;i<group.size();) {
        	if(group.get(groupsize-i).getVmamount()==group.get(groupsize-i).getFlavoramount()) {
	        	return group.get(groupsize-i);
	        }else if(i<=group.size()) {
	        	i++;
	        }else {
	        	System.err.println("VMamount has changed unexpectly");
	        }
        }
        return null;
//        	if(group.get(groupsize-1).vmamount==group.get(groupsize-1).getFlavoramount()) {
//	        	return group.get(groupsize-1);
//	        }else {
//	        	LogUtil.printLog("VMamount has changed unexpectly");
//	            return null;
//	        }    
    }

    public void printcpuneed(){
        int i=1;
        for(DNA dna : group){
            System.out.println(i+" "+dna.getFlavoramount());
            i++;
        }
    }

}   
