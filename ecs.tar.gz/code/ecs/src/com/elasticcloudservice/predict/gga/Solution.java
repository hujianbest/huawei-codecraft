package com.elasticcloudservice.predict.gga;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.elasticcloudservice.predict.base.*;

public class Solution{
    public static DNA solution(Map<Flavor,Integer> prdtresult,InputMsg input){

        List<Flavor> VMdata = new LinkedList<>();
        int flavor_id = 0;
        for(Flavor f : prdtresult.keySet()){
            for(int i=0;i<prdtresult.get(f);i++){
                flavor_id++;
                VMdata.add(new Flavor(flavor_id, f.getName(), f.getCpu(), f.getRamMB()));
            }
        }

        int cpuneed=0;
        int ramneed=0;
        //System.out.println();
        for(Flavor f: VMdata){
            cpuneed+=f.getCpu();
            ramneed+=f.getRamMB();
            //System.out.println(f.toString());
        }
        
        int minCpu = input.getServerstds().get(0).getCPUStd();
        int minRam = input.getServerstds().get(0).getRAMMBStd();
        for(ServerStd sd: input.getServerstds()){
            minCpu=Math.min(minCpu, sd.getCPUStd());
            minRam=Math.min(minRam, sd.getRAMMBStd());
        }

        
        int servermin = Math.max((int)((cpuneed/minCpu)+1),(int)((ramneed/minRam)+1));
        int serveramonut = (int)(servermin*3);
        int numOfServerstd = input.getNumOfServerstds();
        List<ServerStd> serverstds = input.getServerstds();
        int groupsize = 300;
        double ratec = 0.5;
        double ratem = 0.2;
        int generation = 30;

        Evolution evolution = new Evolution(VMdata, numOfServerstd,serverstds, serveramonut, groupsize, ratec, ratem, generation);
        //System.err.println("遗传算法开始");
        evolution.start();
        //evolution.printcpuneed();
        //System.err.println("理想情况下的最小服务器数量 = "+servermin);
        //System.err.println("CPU最高利用率 = "+((double)cpuneed/(servermin*serverstd.getCPUStd())));
        //System.err.println("RAM最高利用率 = "+((double)ramneed/(servermin*serverstd.getRAMMBStd())));
        //System.err.println("当前CPU利用率  = "+evolution.end().getCpuFitness());
        //System.err.println("当前RAM利用率  = "+evolution.end().getRamFitness());
        //System.err.println("当前总体利用率  = "+evolution.end().getFitness());
        return evolution.end();

    }
}
