package com.elasticcloudservice.predict.funs;

import java.util.Map;

import com.elasticcloudservice.predict.base.*;

//单天超过10就视为异常
public class Filter{
    public static void filte(Map<Flavor,Map<String,Integer>> orgDataWithZeros){
        for(Flavor f : orgDataWithZeros.keySet()){
            for(String s : orgDataWithZeros.get(f).keySet()){
                if(orgDataWithZeros.get(f).get(s)>10){
                    orgDataWithZeros.get(f).put(s, 5);
                }
            }
        }
    }
}
